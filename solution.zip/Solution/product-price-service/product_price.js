module.exports = function (options) {
    //Import the mock data json file
    const mockData = require('./MOCK_DATA.json');
    //To DO: Add the patterns and their corresponding functions
    this.add('role:Product,cmd:Price', getProductPrice);

    //To DO: add the pattern functions and describe the logic inside the function
    function getProductPrice(msg, respond) {
        if(msg.productId){
            var res = mockData.find(function(elem){ if (elem.product_id == msg.productId){ return elem } })
            respond(null, { result: res.product_price });
        }
        else {
            respond(null, { result: ''});
        }
    }
}